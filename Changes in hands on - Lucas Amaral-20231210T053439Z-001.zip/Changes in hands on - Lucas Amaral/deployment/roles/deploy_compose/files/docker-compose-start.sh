#!/bin/sh
nohup docker-compose up -d >/dev/null 2>&1 &
